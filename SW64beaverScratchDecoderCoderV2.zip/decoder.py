
# this is pretty epic

var2 = True
while var2 is True:
    var1 = input()
    var1 = var1.replace('a', '§').replace('b', 'a').replace('§', 'b')
    var1 = var1.replace('c', '¦').replace('d', 'c').replace('¦', 'd')
    var1 = var1.replace('e', '¤').replace('f', 'e').replace('¤', 'f')
    var1 = var1.replace('g', '¢').replace('h', 'g').replace('¢', 'h')
    var1 = var1.replace('i', '¡').replace('j', 'i').replace('¡', 'j')
    var1 = var1.replace('k', 'Ÿ').replace('l', 'k').replace('Ÿ', 'l')
    var1 = var1.replace('m', 'ž').replace('n', 'm').replace('ž', 'n')
    var1 = var1.replace('o', 'œ').replace('p', 'o').replace('œ', 'p')
    var1 = var1.replace('q', '›').replace('r', 'q').replace('›', 'r')
    var1 = var1.replace('s', 'š').replace('t', 's').replace('š', 't')
    var1 = var1.replace('u', '•').replace('v', 'u').replace('•', 'v')
    var1 = var1.replace('w', 'Ž').replace('x', 'w').replace('Ž', 'x')
    var1 = var1.replace('y', 'Œ').replace('z', 'y').replace('Œ', 'z')
    var1.replace('A', 'Š').replace('B', 'A').replace('Š', 'B')
    var1 = var1.replace('C', '╟').replace('D', 'C').replace('╟', 'D')
    var1 = var1.replace('E', '‡').replace('F', 'E').replace('‡', 'F')
    var1 = var1.replace('G', '†').replace('H', 'G').replace('†', 'H')
    var1 = var1.replace('I', '…').replace('J', 'I').replace('…', 'J')
    var1 = var1.replace('K', '„').replace('L', 'K').replace('„', 'L')
    var1 = var1.replace('M', 'ƒ').replace('N', 'M').replace('ƒ', 'N')
    var1 = var1.replace('O', '¶').replace('P', 'O').replace('¶', 'P')
    var1 = var1.replace('Q', '·').replace('R', 'Q').replace('·', 'R')
    var1 = var1.replace('S', '¸').replace('T', 'S').replace('¸', 'T')
    var1 = var1.replace('U', '¹').replace('V', 'U').replace('¹', 'V')
    var1 = var1.replace('W', 'º').replace('X', 'W').replace('º', 'X')
    var1 = var1.replace('Y', '»').replace('Z', 'Y').replace('»', 'Z')
    print(var1)
    print(



   "Anything else: ")