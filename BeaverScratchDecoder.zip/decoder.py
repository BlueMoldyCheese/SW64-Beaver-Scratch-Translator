
# PROUDLY CREATED BY THE ONE AND ONLY BLUEMOLDYCHEESE

beaverScratch=True
print("Type any message in beaver scratch to convert it to English. Or type a message in English to convert it to beaver scratch. :)")
while beaverScratch is True:
  var1 = input().lower()
  var1 = var1.replace('a', '1').replace('b', 'a').replace('1', 'b')
  var1 = var1.replace('c', '2').replace('d', 'c').replace('2', 'd')
  var1 = var1.replace('e', '3').replace('f', 'e').replace('3', 'f')
  var1 = var1.replace('g', '4').replace('h', 'g').replace('4', 'h')
  var1 = var1.replace('i', '5').replace('j', 'i').replace('5', 'j')
  var1 = var1.replace('k', '6').replace('l', 'k').replace('6', 'l')
  var1 = var1.replace('m', '7').replace('n', 'm').replace('7', 'n')
  var1 = var1.replace('o', '8').replace('p', 'o').replace('8', 'p')
  var1 = var1.replace('q', '9').replace('r', 'q').replace('9', 'r')
  var1 = var1.replace('s', '10').replace('t', 's').replace('10', 't')
  var1 = var1.replace('u', '11').replace('v', 'u').replace('11', 'v')
  var1 = var1.replace('w', '12').replace('x', 'w').replace('12', 'x')
  var1 = var1.replace('y', '13').replace('z', 'y').replace('13', 'z')
  print(var1)
  print(

 "Anything else: " )